// collectors/install-opencode.mjs
//
// 安装/卸载 opencode-collector-plugin 到 ~/.config/opencode/opencode.jsonc
//
// 用法：
//   node collectors/install-opencode.mjs install    # 安装（备份原文件 + 加 plugin 引用）
//   node collectors/install-opencode.mjs uninstall  # 卸载（移除 plugin 引用，恢复备份）
//   node collectors/install-opencode.mjs status      # 查看当前状态
//
// 约束：
// - 备份原文件到 opencode.jsonc.collector.bak（首次安装时）
// - 不触碰 providers/models/permissions 等其他配置
// - plugin 路径用绝对路径引用，指向本仓库 collectors/opencode-collector-plugin

import fs from "node:fs";
import path from "node:path";
import os from "node:os";

const PLUGIN_DIR = path.resolve(
  path.dirname(new URL(import.meta.url).pathname.replace(/^\//, "")),
  "opencode-collector-plugin"
).replace(/\//g, path.sep);

const OC_CONFIG_DIR = path.join(os.homedir(), ".config", "opencode");
const OC_CONFIG = path.join(OC_CONFIG_DIR, "opencode.jsonc");
const OC_BACKUP = path.join(OC_CONFIG_DIR, "opencode.jsonc.collector.bak");

// 去除 JSONC 注释（// 和 /* */），保留字符串内的 //
function stripJsoncComments(text) {
  let result = "";
  let i = 0;
  let inString = false;
  let stringChar = "";
  while (i < text.length) {
    const ch = text[i];
    const next = text[i + 1];
    if (inString) {
      if (ch === "\\") {
        result += ch + (next || "");
        i += 2;
        continue;
      }
      if (ch === stringChar) inString = false;
      result += ch;
      i++;
      continue;
    }
    if (ch === '"' || ch === "'") {
      inString = true;
      stringChar = ch;
      result += ch;
      i++;
      continue;
    }
    if (ch === "/" && next === "/") {
      // 行注释
      while (i < text.length && text[i] !== "\n") i++;
      continue;
    }
    if (ch === "/" && next === "*") {
      i += 2;
      while (i < text.length && !(text[i] === "*" && text[i + 1] === "/")) i++;
      i += 2;
      continue;
    }
    result += ch;
    i++;
  }
  return result;
}

function readConfig() {
  if (!fs.existsSync(OC_CONFIG)) {
    throw new Error(`opencode.jsonc not found at ${OC_CONFIG}`);
  }
  const raw = fs.readFileSync(OC_CONFIG, "utf8");
  const json = stripJsoncComments(raw);
  return { raw, parsed: JSON.parse(json) };
}

function writeConfig(obj) {
  const out =
    "{\n" +
    '  "$schema": "https://opencode.ai/config.json",\n' +
    Object.keys(obj)
      .filter((k) => k !== "$schema")
      .map((k) => {
        const v = obj[k];
        return `  ${JSON.stringify(k)}: ${JSON.stringify(v, null, 2).replace(/\n/g, "\n  ")}`;
      })
      .join(",\n") +
    "\n}\n";
  fs.writeFileSync(OC_CONFIG, out, "utf8");
}

function pluginAlreadyListed(plugins) {
  if (!Array.isArray(plugins)) return false;
  return plugins.some((p) => {
    if (typeof p === "string") return p === PLUGIN_DIR;
    if (p && typeof p === "object" && typeof p.package === "string")
      return p.package === PLUGIN_DIR;
    return false;
  });
}

function install() {
  if (!fs.existsSync(PLUGIN_DIR)) {
    throw new Error(`plugin dir not found: ${PLUGIN_DIR}`);
  }
  const { raw, parsed } = readConfig();
  // 首次安装备份
  if (!fs.existsSync(OC_BACKUP)) {
    fs.writeFileSync(OC_BACKUP, raw, "utf8");
    console.log(`[install] backed up original config → ${OC_BACKUP}`);
  } else {
    console.log(`[install] backup already exists → ${OC_BACKUP} (not overwritten)`);
  }
  if (!Array.isArray(parsed.plugins)) parsed.providers && (parsed.providers = parsed.providers);
  parsed.providers = parsed.providers || {};
  const listed = pluginAlreadyListed(parsed.plugins);
  if (listed) {
    console.log(`[install] plugin already listed in opencode.jsonc, nothing to do`);
    return;
  }
  parsed.plugins = Array.isArray(parsed.plugins) ? [...parsed.plugins, PLUGIN_DIR] : [PLUGIN_DIR];
  writeConfig(parsed);
  console.log(`[install] added plugin reference to opencode.jsonc`);
  console.log(`[install]   path = ${PLUGIN_DIR}`);
  console.log(`[install] restart opencode service: opencode service restart`);
}

function uninstall() {
  if (!fs.existsSync(OC_CONFIG)) {
    console.log(`[uninstall] no config at ${OC_CONFIG}`);
    return;
  }
  const { parsed } = readConfig();
  if (Array.isArray(parsed.plugins)) {
    parsed.plugins = parsed.plugins.filter((p) => {
      if (typeof p === "string") return p !== PLUGIN_DIR;
      if (p && typeof p === "object") return p.package !== PLUGIN_DIR;
      return true;
    });
    if (parsed.plugins.length === 0) delete parsed.plugins;
  }
  writeConfig(parsed);
  console.log(`[uninstall] removed plugin reference from opencode.jsonc`);
  if (fs.existsSync(OC_BACKUP)) {
    console.log(`[uninstall] original backup preserved at ${OC_BACKUP}`);
    console.log(`[uninstall] to fully restore: copy ${OC_BACKUP} → ${OC_CONFIG}`);
  }
  console.log(`[uninstall] restart opencode service: opencode service restart`);
}

function status() {
  if (!fs.existsSync(OC_CONFIG)) {
    console.log(`[status] no config at ${OC_CONFIG}`);
    return;
  }
  const { parsed } = readConfig();
  const listed = pluginAlreadyListed(parsed.plugins);
  console.log(`[status] plugin installed: ${listed}`);
  console.log(`[status] plugin path: ${PLUGIN_DIR}`);
  console.log(`[status] plugin dir exists: ${fs.existsSync(PLUGIN_DIR)}`);
  console.log(`[status] backup exists: ${fs.existsSync(OC_BACKUP)}`);
  console.log(`[status] providers: ${Object.keys(parsed.providers || {}).join(", ")}`);
}

const cmd = process.argv[2] || "status";
try {
  if (cmd === "install") install();
  else if (cmd === "uninstall") uninstall();
  else status();
} catch (e) {
  console.error(`[error] ${e.message}`);
  process.exit(1);
}
